import img
import imgio
import transf
import discret
import split
import match
from PIL import Image

#programa principal


print(match(read_bn("2n2021/1matricula/sortida/digit_3.jpeg"),load_patterns()))